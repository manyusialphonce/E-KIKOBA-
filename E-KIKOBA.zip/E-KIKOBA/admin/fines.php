<?php
session_start(); // 🔹 Hii lazima iwe juu kabisa
include("../config/db.php");
include("../includes/header.php");
include("../includes/sidebar_admin.php");

// Only admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<p style='color:red;'>Access denied. You are not an admin.</p>";
    exit;
}

$kikoba_id = $_SESSION['kikoba_id'] ?? 0;

// Update fine status if admin clicked "Mark as Paid"
if (isset($_GET['mark_paid'])) {
    $fine_id = (int)$_GET['mark_paid'];
    $conn->query("UPDATE fines SET status='paid' WHERE id=$fine_id AND kikoba_id=$kikoba_id");
    header("Location: fines.php");
    exit;
}

// Fetch fines for this Kikoba
$fines = $conn->query("
    SELECT f.*, u.full_name
    FROM fines f
    JOIN members m ON f.member_id = m.id
    JOIN users u ON m.user_id = u.id
    WHERE f.kikoba_id = $kikoba_id
    ORDER BY f.id DESC
");
?>

<div class="main">
    <div class="topbar">
        <h2>Fines</h2>
        <small>View and manage fines for your Kikoba members</small>
    </div>

    <div class="table-box">
        <table>
            <tr>
                <th>Member</th>
                <th>Reason</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while($f = $fines->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($f['full_name']) ?></td>
                <td><?= htmlspecialchars($f['reason']) ?></td>
                <td><?= number_format($f['amount']) ?></td>
                <td>
                    <span class="badge <?= $f['status']=='paid'?'success':'pending' ?>">
                        <?= ucfirst($f['status']) ?>
                    </span>
                </td>
                <td>
                    <?php if($f['status']=='unpaid'): ?>
                        <a href="?mark_paid=<?= $f['id'] ?>" class="btn primary" onclick="return confirm('Mark this fine as paid?')">
                            Mark as Paid
                        </a>
                    <?php else: ?>
                        <span class="badge success">Paid</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

<?php include("../includes/footer.php"); ?>
