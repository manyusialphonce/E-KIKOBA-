<?php
include("../config/db.php");
include("../includes/header.php");
include("../includes/sidebar_admin.php");

$contributions = $conn->query("SELECT SUM(amount) total FROM contributions")->fetch_assoc()['total'];
$loans         = $conn->query("SELECT SUM(amount) total FROM loans WHERE status='approved'")->fetch_assoc()['total'];
$pendingLoans  = $conn->query("SELECT COUNT(*) total FROM loans WHERE status='pending'")->fetch_assoc()['total'];
?>

<div class="main">
    <div class="topbar">
        <h2>Financial Reports</h2>
    </div>

    <div class="cards">
        <div class="card">
            <h3>Total Contributions</h3>
            <p><?= number_format($contributions) ?></p>
        </div>
        <div class="card">
            <h3>Total Loans Released</h3>
            <p><?= number_format($loans) ?></p>
        </div>
        <div class="card">
            <h3>Pending Loan Requests</h3>
            <p><?= $pendingLoans ?></p>
        </div>
    </div>

    <br>

    <button onclick="window.print()" class="btn primary">
        Print Report
    </button>
</div>

<?php include("../includes/footer.php"); ?>