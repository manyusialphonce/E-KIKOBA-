<?php
include("../config/db.php");
include("../includes/header.php");
include("../includes/sidebar_admin.php");

/* COUNTS & TOTALS */
$members = $conn->query(
    "SELECT COUNT(*) t FROM users WHERE role='member'"
)->fetch_assoc()['t'];

$contributions = $conn->query(
    "SELECT IFNULL(SUM(amount),0) t FROM contributions"
)->fetch_assoc()['t'];

$loans = $conn->query(
    "SELECT IFNULL(SUM(amount),0) t FROM loans WHERE status='approved'"
)->fetch_assoc()['t'];

$pending = $conn->query(
    "SELECT COUNT(*) t FROM loans WHERE status='pending'"
)->fetch_assoc()['t'];

/* RECENT LOANS */
$recentLoans = $conn->query("
    SELECT 
        u.full_name,
        l.amount,
        l.status
    FROM loans l
    JOIN members m ON m.id = l.member_id
    JOIN users u ON u.id = m.user_id
    ORDER BY l.id DESC
    LIMIT 5
");
?>

<div class="main">

    <div class="topbar">
        <h2>Admin Dashboard</h2>
        <small>Overview of Kikoba Activities</small>
    </div>

    <div class="cards">
        <div class="card">
            <h3>Total Members</h3>
            <p><?= $members ?></p>
            <span class="icon">👥</span>
        </div>

        <div class="card">
            <h3>Total Contributions</h3>
            <p><?= number_format($contributions) ?></p>
            <span class="icon">💰</span>
        </div>

        <div class="card">
            <h3>Loans Released</h3>
            <p><?= number_format($loans) ?></p>
            <span class="icon">🏦</span>
        </div>

        <div class="card">
            <h3>Pending Loans</h3>
            <p><?= $pending ?></p>
            <span class="icon">⏳</span>
        </div>
    </div>

    <div class="table-box">
        <h3>Recent Loan Requests</h3><br>

        <table>
            <tr>
                <th>Member</th>
                <th>Amount</th>
                <th>Status</th>
            </tr>

            <?php while($r = $recentLoans->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($r['full_name']) ?></td>
                <td><?= number_format($r['amount']) ?></td>
                <td>
                    <span class="badge 
                        <?= $r['status']=='approved'
                            ? 'success'
                            : ($r['status']=='pending' ? 'pending' : 'danger') ?>">
                        <?= ucfirst($r['status']) ?>
                    </span>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<?php include("../includes/footer.php"); ?>
