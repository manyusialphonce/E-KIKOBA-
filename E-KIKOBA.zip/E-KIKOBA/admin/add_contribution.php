<?php
include("../config/db.php");
if ($_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
}

$kikoba_id = $_SESSION['kikoba_id'];

// pata members wa kikoba hiki
$members = $conn->query("
 SELECT m.id AS member_id, u.full_name
 FROM members m
 JOIN users u ON m.user_id = u.id
 WHERE m.kikoba_id = $kikoba_id
");

if (isset($_POST['save'])) {
    $member_id = $_POST['member_id'];
    $amount = $_POST['amount'];
    $month  = $_POST['month'];
    $year   = $_POST['year'];

    // insert contribution
    $stmt = $conn->prepare(
      "INSERT INTO contributions (kikoba_id, member_id, amount, month, year)
       VALUES (?,?,?,?,?)"
    );
    $stmt->bind_param("iidss", $kikoba_id, $member_id, $amount, $month, $year);
    $stmt->execute();

    // update total contribution
    $conn->query("
      UPDATE members
      SET total_contribution = total_contribution + $amount
      WHERE id = $member_id
    ");

    echo "Contribution recorded successfully!";
}
?>

<h2>Add Contribution</h2>

<form method="POST">
    <select name="member_id" required>
        <option value="">Select Member</option>
        <?php while($m = $members->fetch_assoc()) { ?>
            <option value="<?= $m['member_id'] ?>">
                <?= $m['full_name'] ?>
            </option>
        <?php } ?>
    </select><br><br>

    <input type="number" name="amount" placeholder="Amount" required><br><br>

    <input name="month" placeholder="Month (e.g January)" required><br><br>

    <input type="number" name="year" value="<?= date('Y') ?>" required><br><br>

    <button name="save">Save Contribution</button>
</form>