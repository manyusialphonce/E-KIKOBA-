<?php
include("../config/db.php");
if ($_SESSION['role'] != 'admin') header("Location: ../auth/login.php");

$kikoba_id = $_SESSION['kikoba_id'];

if(isset($_POST['add'])){
    $title=$_POST['title'];
    $date=$_POST['date'];
    $amount=$_POST['amount'];

    $stmt=$conn->prepare(
      "INSERT INTO events (kikoba_id,title,event_date,contribution_amount)
       VALUES (?,?,?,?)"
    );
    $stmt->bind_param("issd",$kikoba_id,$title,$date,$amount);
    $stmt->execute();
}

$events=$conn->query("SELECT * FROM events WHERE kikoba_id=$kikoba_id");
?>

<h2>Events</h2>
<form method="POST">
<input name="title" placeholder="Event Name" required><br>
<input type="date" name="date" required><br>
<input type="number" name="amount" placeholder="Contribution"><br>
<button name="add">Add Event</button>
</form>

<ul>
<?php while($e=$events->fetch_assoc()){ ?>
<li><?= $e['title'] ?> - <?= $e['event_date'] ?></li>
<?php } ?>
</ul>