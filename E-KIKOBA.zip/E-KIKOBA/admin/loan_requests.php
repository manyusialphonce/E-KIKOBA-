<?php
include("../config/db.php");
if ($_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
}

$kikoba_id = $_SESSION['kikoba_id'];

if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $conn->query("UPDATE loans SET status='approved' WHERE id=$id");
}

if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    $conn->query("UPDATE loans SET status='completed' WHERE id=$id");
}

$loans = $conn->query("
 SELECT l.*, u.full_name
 FROM loans l
 JOIN members m ON l.member_id = m.id
 JOIN users u ON m.user_id = u.id
 WHERE l.kikoba_id = $kikoba_id
 ORDER BY l.id DESC
");
?>

<h2>Loan Requests</h2>

<table border="1" cellpadding="10">
<tr>
  <th>Member</th>
  <th>Amount</th>
  <th>Interest</th>
  <th>Status</th>
  <th>Action</th>
</tr>

<?php while($l = $loans->fetch_assoc()) { ?>
<tr>
  <td><?= $l['full_name'] ?></td>
  <td><?= $l['amount'] ?></td>
  <td><?= $l['interest'] ?>%</td>
  <td><?= $l['status'] ?></td>
  <td>
    <?php if ($l['status'] == 'pending') { ?>
      <a href="?approve=<?= $l['id'] ?>">Approve</a> |
      <a href="?reject=<?= $l['id'] ?>">Reject</a>
    <?php } ?>
  </td>
</tr>
<?php } ?>
</table>