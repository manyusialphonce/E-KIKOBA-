<?php
include("../config/db.php");
include("../includes/header.php");
include("../includes/sidebar_admin.php");

// Handle approval
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $conn->query("UPDATE loans SET status='approved' WHERE id=$id");
}

if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    $conn->query("UPDATE loans SET status='rejected' WHERE id=$id");
}

$q = $conn->query("
    SELECT loans.*, users.fullname 
    FROM loans 
    JOIN users ON loans.user_id = users.id
");
?>

<div class="main">
    <div class="topbar">
        <h2>Loan Management</h2>
    </div>

    <table>
        <tr>
            <th>#</th>
            <th>Member</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php $i=1; while($row=$q->fetch_assoc()): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= $row['fullname'] ?></td>
            <td><?= number_format($row['amount']) ?></td>
            <td>
                <span class="badge 
                    <?= $row['status']=='approved'?'success':($row['status']=='rejected'?'danger':'pending') ?>">
                    <?= ucfirst($row['status']) ?>
                </span>
            </td>
            <td>
                <?php if($row['status']=='pending'): ?>
                    <a class="btn primary" href="?approve=<?= $row['id'] ?>">Approve</a>
                    <a class="btn danger" href="?reject=<?= $row['id'] ?>">Reject</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include("../includes/footer.php"); ?>