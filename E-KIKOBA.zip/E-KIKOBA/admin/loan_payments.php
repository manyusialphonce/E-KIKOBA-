<?php
include("../config/db.php");
if ($_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
}

$loan_id = $_GET['loan_id'];

if (isset($_POST['pay'])) {
    $amount = $_POST['amount'];
    $date   = date('Y-m-d');

    $stmt = $conn->prepare(
      "INSERT INTO loan_payments (loan_id, amount, payment_date)
       VALUES (?,?,?)"
    );
    $stmt->bind_param("ids", $loan_id, $amount, $date);
    $stmt->execute();

    echo "Payment recorded!";
}
?>

<h2>Loan Payment</h2>

<form method="POST">
    <input type="number" name="amount" placeholder="Payment Amount" required><br><br>
    <button name="pay">Save Payment</button>
</form>