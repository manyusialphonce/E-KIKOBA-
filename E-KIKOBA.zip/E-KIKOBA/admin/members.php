<?php
include("../config/db.php");
include("../includes/header.php");
include("../includes/sidebar_admin.php");

$q = $conn->query("SELECT full_name, email FROM users WHERE role='member'");
?>

<div class="main">

    <div class="topbar">
        <h2>Members</h2>
        <small>All registered members</small>
    </div>

    <div class="table-box">
        <table>
            <tr>
                <th>#</th>
                <th>Full Name</th>
                <th>Email</th>
            </tr>

            <?php $i=1; while($r = $q->fetch_assoc()): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($r['full_name']) ?></td>
                <td><?= htmlspecialchars($r['email']) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<?php include("../includes/footer.php"); ?>
