<?php
include("../config/db.php");
if ($_SESSION['role'] != 'admin') header("Location: ../auth/login.php");

$kikoba_id = $_SESSION['kikoba_id'];

$members = $conn->query("
 SELECT m.id, u.full_name
 FROM members m
 JOIN users u ON m.user_id = u.id
 WHERE m.kikoba_id = $kikoba_id
");

if(isset($_POST['save'])){
    $member = $_POST['member_id'];
    $reason = $_POST['reason'];
    $amount = $_POST['amount'];

    $stmt = $conn->prepare(
      "INSERT INTO fines (kikoba_id, member_id, reason, amount)
       VALUES (?,?,?,?)"
    );
    $stmt->bind_param("iisd", $kikoba_id, $member, $reason, $amount);
    $stmt->execute();

    echo "Fine added successfully!";
}
?>

<h2>Add Fine</h2>
<form method="POST">
<select name="member_id" required>
<?php while($m=$members->fetch_assoc()){ ?>
<option value="<?= $m['id'] ?>"><?= $m['full_name'] ?></option>
<?php } ?>
</select><br><br>

<input name="reason" placeholder="Reason" required><br><br>
<input type="number" name="amount" placeholder="Amount" required><br><br>
<button name="save">Save Fine</button>
</form>