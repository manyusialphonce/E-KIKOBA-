<?php
include("../config/db.php");
include("../includes/header.php");
include("../includes/sidebar_admin.php");

$q = $conn->query("
    SELECT 
        u.full_name,
        c.amount,
        c.created_at
    FROM contributions c
    JOIN members m ON m.id = c.member_id
    JOIN users u ON u.id = m.user_id
    ORDER BY c.id DESC
");
?>

<div class="main">

    <div class="topbar">
        <h2>All Contributions</h2>
        <small>Members monthly contributions</small>
    </div>

    <div class="table-box">
        <table>
            <tr>
                <th>#</th>
                <th>Member</th>
                <th>Amount</th>
                <th>Date</th>
            </tr>

            <?php $i=1; while($r = $q->fetch_assoc()): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($r['full_name']) ?></td>
                <td><?= number_format($r['amount']) ?></td>
                <td><?= date("d M Y", strtotime($r['created_at'])) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<?php include("../includes/footer.php"); ?>
